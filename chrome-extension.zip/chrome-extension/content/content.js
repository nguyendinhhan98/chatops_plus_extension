/**
 * Content Script cho trang chat.runsystem.vn
 * Nhúng một floating button để mở nhanh ChatOps Extension Side Panel.
 */

(function () {
  // Tránh tạo nhiều nút nếu script chạy nhiều lần
  if (document.getElementById('chatops-ext-floating-btn')) return;

  const btn = document.createElement('div');
  btn.id = 'chatops-ext-floating-btn';
  btn.title = 'Mở ChatOps Helper';
  btn.style.cursor = 'pointer';

  const BUBBLE_SVG = `
    <svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" style="width:100%; height:100%; display:block;">
      <circle cx="256" cy="240" r="210" fill="#43a047"/>
      <path d="M160 400 L120 480 L260 420" fill="#43a047"/>
      <circle cx="165" cy="240" r="32" fill="white"/>
      <circle cx="256" cy="240" r="32" fill="white"/>
      <circle cx="347" cy="240" r="32" fill="white"/>
    </svg>
  `;

  btn.innerHTML = BUBBLE_SVG;

  // Thêm nút X nhỏ để tắt hẳn floating button nếu cần
  const closeIconBtn = document.createElement('div');
  closeIconBtn.id = 'chatops-ext-close-btn';
  closeIconBtn.innerHTML = '×';
  closeIconBtn.title = 'Ẩn nút này';
  btn.appendChild(closeIconBtn);

  closeIconBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    btn.remove(); // Xóa hẳn khỏi DOM trang hiện tại
  });

  // Thêm vào body
  document.body.appendChild(btn);

  // Restore position from localStorage
  const savedPos = localStorage.getItem('chatops_ext_btn_pos');
  if (savedPos) {
    try {
      const pos = JSON.parse(savedPos);
      btn.style.top = pos.top;
      btn.style.left = pos.left;
      btn.style.right = 'auto';
      btn.style.transform = 'none';
    } catch(e) {}
  }

  // Drag logic
  let isDragging = false;
  let hasMoved = false;
  let startX, startY, initialX, initialY;

  btn.addEventListener('mousedown', (e) => {
    // Only handle left click
    if (e.button !== 0) return;
    isDragging = true;
    hasMoved = false;
    startX = e.clientX;
    startY = e.clientY;
    
    const rect = btn.getBoundingClientRect();
    initialX = rect.left;
    initialY = rect.top;
    
    btn.classList.add('dragging');
    btn.style.right = 'auto';
    btn.style.transform = 'none';
  });

  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
      hasMoved = true;
    }

    if (hasMoved) {
      let newX = initialX + dx;
      let newY = initialY + dy;
      
      const maxX = window.innerWidth - btn.offsetWidth;
      const maxY = window.innerHeight - btn.offsetHeight;
      
      newX = Math.max(0, Math.min(newX, maxX));
      newY = Math.max(0, Math.min(newY, maxY));
      
      btn.style.left = `${newX}px`;
      btn.style.top = `${newY}px`;
    }
  });

  document.addEventListener('mouseup', () => {
    if (isDragging) {
      isDragging = false;
      btn.classList.remove('dragging');
      
      if (hasMoved) {
        localStorage.setItem('chatops_ext_btn_pos', JSON.stringify({
          top: btn.style.top,
          left: btn.style.left
        }));
      }
      
      // Delay reset hasMoved so click event can check it
      setTimeout(() => { hasMoved = false; }, 50);
    }
  });

  // Xử lý sự kiện click
  btn.addEventListener('click', (e) => {
    if (hasMoved) {
      e.preventDefault();
      return;
    }
    
    // Gửi message tới background script để toggle Side Panel
    try {
      chrome.runtime.sendMessage({ type: 'TOGGLE_SIDE_PANEL' }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn('[ChatOps Ext] Error toggling side panel:', chrome.runtime.lastError.message);
        }
      });
    } catch (err) {
      if (err.message.includes('Extension context invalidated')) {
        alert('Trợ lý ChatOps vừa được cập nhật bản mới! Vui lòng ấn F5 tải lại trang để tiếp tục sử dụng.');
      }
    }
  });

  console.log('[ChatOps Ext] Floating button injected.');

  // ─── Meme Integration into Main UI ───

  function injectMemeButton() {
    const emojiBtn = document.getElementById('emojiPickerButton');
    if (!emojiBtn || document.getElementById('chatops-ext-meme-btn')) return;

    const memeBtn = document.createElement('button');
    memeBtn.id = 'chatops-ext-meme-btn';
    memeBtn.type = 'button';
    memeBtn.innerHTML = '🖼️';
    memeBtn.title = 'Chèn Meme nhanh';
    
    // Chèn sau nút Emoji
    emojiBtn.parentNode.insertBefore(memeBtn, emojiBtn.nextSibling);

    memeBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleMemePickerUI(memeBtn);
    });
  }

  let memePickerEl = null;
  function toggleMemePickerUI(anchorBtn) {
    if (!memePickerEl) {
      memePickerEl = document.createElement('div');
      memePickerEl.className = 'chatops-meme-picker hidden';
      memePickerEl.innerHTML = `
        <div class="chatops-meme-picker-header">
          <span>😂 Kho Memes</span>
          <button type="button" id="chatops-meme-close" style="background:none; border:none; cursor:pointer;">✖</button>
        </div>
        <div id="chatops-meme-grid" class="chatops-meme-picker-grid">
          <div style="grid-column: 1/-1; text-align:center; padding: 20px;">Đang tải...</div>
        </div>
      `;
      document.body.appendChild(memePickerEl);

      document.getElementById('chatops-meme-close').addEventListener('click', () => {
        memePickerEl.classList.add('hidden');
      });

      // Event delegation for grid
      document.getElementById('chatops-meme-grid').addEventListener('click', (e) => {
        const img = e.target.closest('.chatops-meme-item');
        if (img) {
          insertMemeToChat(img.src);
          memePickerEl.classList.add('hidden');
        }
      });

      loadMemesToMainUI();
    }

    const isHidden = memePickerEl.classList.contains('hidden');
    if (isHidden) {
      // Position it above the anchor button
      const rect = anchorBtn.getBoundingClientRect();
      memePickerEl.style.bottom = `${window.innerHeight - rect.top + 10}px`;
      memePickerEl.style.left = `${Math.max(10, rect.left - 260)}px`;
      memePickerEl.classList.remove('hidden');
    } else {
      memePickerEl.classList.add('hidden');
    }
  }

  async function loadMemesToMainUI() {
    const grid = document.getElementById('chatops-meme-grid');
    try {
      const [imgflipRes, redditRes] = await Promise.allSettled([
        fetch('https://api.imgflip.com/get_memes').then(r => r.json()),
        fetch('https://meme-api.com/gimme/50').then(r => r.json())
      ]);

      let allMemes = [];
      if (imgflipRes.status === 'fulfilled' && imgflipRes.value.success) {
        allMemes.push(...imgflipRes.value.data.memes.map(m => ({ url: m.url })));
      }
      if (redditRes.status === 'fulfilled' && redditRes.value.memes) {
        allMemes.push(...redditRes.value.memes.map(m => ({ url: m.url })));
      }
      allMemes.sort(() => Math.random() - 0.5);
      
      grid.innerHTML = allMemes.slice(0, 60).map(m => `
        <img src="${m.url}" class="chatops-meme-item" loading="lazy" />
      `).join('');
    } catch (err) {
      grid.innerHTML = '<div style="grid-column: 1/-1; padding:20px; color:red;">Lỗi tải memes.</div>';
    }
  }

  function insertMemeToChat(url) {
    const textarea = document.getElementById('post_textbox');
    if (!textarea) {
      console.warn('[ChatOps Ext] Không tìm thấy ô nhập liệu #post_textbox');
      return;
    }

    const markdown = `![meme](${url})`;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    
    textarea.value = text.substring(0, start) + markdown + text.substring(end);
    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = start + markdown.length;
    
    // Trigger input event for React/Mattermost to detect change
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
  }

  // Monitor for emoji button
  const observer = new MutationObserver(() => {
    injectMemeButton();
  });
  observer.observe(document.body, { childList: true, subtree: true });
  
  // Initial check
  injectMemeButton();
})();
